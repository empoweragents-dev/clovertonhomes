module.exports=[94387,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_properties_new_page_actions_dcd9b449.js.map