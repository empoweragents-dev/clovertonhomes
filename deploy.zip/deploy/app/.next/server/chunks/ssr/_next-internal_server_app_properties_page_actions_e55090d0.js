module.exports=[80021,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_properties_page_actions_e55090d0.js.map