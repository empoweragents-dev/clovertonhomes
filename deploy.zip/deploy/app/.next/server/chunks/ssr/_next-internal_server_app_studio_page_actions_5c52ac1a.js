module.exports=[84638,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_studio_page_actions_5c52ac1a.js.map