module.exports=[34047,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_properties_%5Bid%5D_page_actions_8160e558.js.map