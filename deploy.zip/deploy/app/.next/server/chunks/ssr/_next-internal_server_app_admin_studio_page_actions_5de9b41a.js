module.exports=[38937,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_studio_page_actions_5de9b41a.js.map