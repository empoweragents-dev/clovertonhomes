module.exports=[65282,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_interiors_page_actions_2e62d6c5.js.map