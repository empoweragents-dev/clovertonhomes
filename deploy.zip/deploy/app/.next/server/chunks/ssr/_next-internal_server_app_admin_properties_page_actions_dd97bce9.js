module.exports=[31465,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_properties_page_actions_dd97bce9.js.map