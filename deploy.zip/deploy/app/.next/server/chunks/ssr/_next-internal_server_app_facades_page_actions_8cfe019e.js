module.exports=[13705,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_facades_page_actions_8cfe019e.js.map