globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/4faa7d2e5bb46393.js",
    "static/chunks/248cba0fcb3874ed.js",
    "static/chunks/6740f161f60c6ab5.js",
    "static/chunks/023d923a37d494fc.js",
    "static/chunks/497f7b5edc7d3fce.js",
    "static/chunks/turbopack-93e5a51af43976be.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];