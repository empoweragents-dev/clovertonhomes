# Brochures Directory

Place your PDF brochures here with the following naming convention:

- `standard-inclusions.pdf` - Standard tier brochure
- `designer-inclusions.pdf` - Designer tier brochure
- `premium-inclusions.pdf` - Premium tier brochure

These files will be downloadable from the Property Detail page's Inclusions section.
